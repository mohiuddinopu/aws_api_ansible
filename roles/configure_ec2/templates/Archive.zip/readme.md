# Simple PHP Website

I put together this project while introducing to PHP a good friend of mine. I decided to clean it up a bit and put it on Github so anyone new to PHP can have a taste of a very simple and minimal website built with PHP.

MIT License
